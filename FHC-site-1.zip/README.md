# FHC-site

This website will use AI chat bot for FHC website
Future plans are to add JavaScript
